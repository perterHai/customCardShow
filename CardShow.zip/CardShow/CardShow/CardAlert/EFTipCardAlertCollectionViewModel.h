//
//  EFTipCardAlertCollectionViewModel.h
//  CardShow
//
//  Created by 张海龙 on 16/11/10.
//  Copyright © 2016年 张海龙. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface EFTipCardAlertCollectionViewModel : NSObject

@property (nullable, nonatomic, strong) NSString *imageName;
@property (nullable, nonatomic, strong) NSString *tipStr;

@end
